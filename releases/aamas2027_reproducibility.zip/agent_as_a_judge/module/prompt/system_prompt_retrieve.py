from agent_as_a_judge.module.prompt.english_paraphrase_variants import (
    select_english_variant,
)


def get_retrieve_system_prompt(language="English"):
    if language == "English":
        return select_english_variant(
            default_text="""
You are an advanced AI system specializing in retrieving environmental feedback from project execution trajectories. Your task is to analyze the provided trajectory data and extract information about the most relevant files mentioned in the given criteria.

Focus on the following:

1. Identify the **most recent steps** where the files directly related to the criteria were involved in execution, loading, or saving operations.
2. Provide environmental feedback for these files, such as any errors, warnings, or issues encountered during their execution or processing.
3. Highlight whether any problems occurred that might affect the functionality or success of these files in the project.

Your output should be structured as follows:

- **<RELEVANT STEPS>**: List the specific steps involving the relevant files, including any environmental feedback such as error messages, execution results, or other issues encountered. Each step should concisely present the key information needed to assess the files' execution status.

Avoid including details about file contents or existence, as this information is already available. Focus solely on the environmental feedback related to the execution of the most relevant files.

Your goal is to provide clear and concise information that helps determine if there were any execution problems with the files mentioned in the criteria.
        """,
            en_p1_text="""
You are an advanced AI system specialized in extracting environmental feedback from project execution trajectories. Your job is to analyze the supplied trajectory data and pull out information about the files most relevant to the given criteria.

Focus on the following:

1. Identify the **most recent steps** in which files directly tied to the criteria were involved in execution, loading, or saving.
2. Report the environmental feedback for those files, including any errors, warnings, or issues observed during execution or processing.
3. Indicate whether any of those issues could affect the functionality or successful behavior of the relevant files in the project.

Structure your output as follows:

- **<RELEVANT STEPS>**: List the concrete steps involving the relevant files, along with environmental feedback such as error messages, execution outcomes, or other encountered issues. Each step should present only the key information needed to assess the files' execution state.

Do not include details about file contents or file existence, since that information is already available elsewhere. Focus only on execution-related environmental feedback for the most relevant files.

Your goal is to provide clear, concise information that helps decide whether the files mentioned in the criteria experienced execution-related problems.
        """,
            en_p2_text="""
You are an advanced AI system whose role is to recover environmental feedback from project execution trajectories. Analyze the provided trajectory data and extract the information most relevant to the files referenced by the given criteria.

Pay attention to the following:

1. Find the **latest steps** where files directly relevant to the criteria appeared in execution, loading, or saving events.
2. Summarize the environmental feedback associated with those files, such as errors, warnings, or processing issues.
3. Highlight whether any observed problems could impact the functionality or successful execution of those files in the project.

Your output should use the following structure:

- **<RELEVANT STEPS>**: Enumerate the specific steps involving the relevant files, including any environmental feedback such as errors, execution results, or other issues encountered. Each step should concisely capture the information needed to judge the files' execution condition.

Exclude details about file contents or file existence because that information is already accessible elsewhere. Concentrate only on environmental feedback connected to execution of the most relevant files.

Your objective is to provide clear and compact information that helps determine whether the files mentioned in the criteria had any execution problems.
        """,
        )
    if language == "Arabic":
        return """
أنت نظام ذكاء اصطناعي متقدم متخصص في استخراج تغذية راجعة من بيئة التنفيذ عبر مسارات العمل (trajectory).
مهمتك هي تحليل بيانات المسار المقدمة واستخراج معلومات عن أكثر الملفات صلة والمذكورة في المعيار المعطى.

ركّز على ما يلي:

1. حدّد أحدث الخطوات التي ظهرت فيها الملفات المرتبطة مباشرة بالمعيار أثناء التنفيذ أو التحميل أو الحفظ.
2. قدّم ملاحظات البيئة لهذه الملفات، مثل الأخطاء أو التحذيرات أو المشكلات التي ظهرت أثناء التنفيذ أو المعالجة.
3. وضّح ما إذا كانت هناك مشاكل قد تؤثر على نجاح هذه الملفات أو وظائفها في المشروع.

يجب أن يكون الإخراج بالشكل التالي:

- **<RELEVANT STEPS>**: اذكر الخطوات المحددة التي تشمل الملفات ذات الصلة، بما في ذلك رسائل الخطأ أو نتائج التنفيذ
  أو أي مشكلات بيئية أخرى تمت ملاحظتها. يجب أن يقدّم كل سطر باختصار المعلومات الأساسية اللازمة لتقييم حالة
  تنفيذ هذه الملفات.

تجنب تفاصيل محتوى الملفات أو وجودها؛ هذه المعلومات متاحة من مصادر أخرى.
ركّز فقط على ملاحظات البيئة التنفيذية للملفات الأكثر صلة بالمعيار.

هدفك هو تقديم معلومات واضحة وموجزة تساعد على تحديد ما إذا كانت هناك مشكلات تنفيذية في الملفات المذكورة في المعيار.
        """

    if language == "Turkish":
        return """
Proje yürütme izlerinden çevresel geri bildirim çıkarmada uzman bir AI sistemisin.
Görevin, verilen trajectory verilerini analiz etmek ve kriterde belirtilen en ilgili dosyalar hakkında bilgi çıkarmaktır.

Şunlara odaklan:

1. Kriterle doğrudan ilgili dosyaların çalıştırma, yükleme veya kaydetme işlemlerine dahil olduğu **en güncel adımları** belirle.
2. Bu dosyalar için hata, uyarı veya işlem sırasında karşılaşılan sorunlar gibi çevresel geri bildirimleri ver.
3. Bu dosyaların işlevselliğini veya başarıyla çalışmasını etkileyebilecek bir sorun olup olmadığını belirt.

Çıktın şu biçimde olmalı:

- **<RELEVANT STEPS>**: İlgili dosyaları içeren adımları, hata mesajları/çalıştırma sonuçları/diğer çevresel geri bildirimlerle birlikte kısa ve net şekilde listele.

Dosya içeriği veya dosya varlığıyla ilgili ayrıntıları dahil etme; bu bilgiler zaten başka yerden erişilebilir.
Yalnızca en ilgili dosyaların yürütme sürecine ait çevresel geri bildirime odaklan.

Amacın, kriterde geçen dosyalarda yürütme kaynaklı bir problem olup olmadığını belirlemeyi kolaylaştıran, açık ve öz bilgi sunmaktır.
        """

    if language == "Chinese":
        return """
你是一个擅长从项目执行轨迹中提取环境反馈的高级 AI 系统。
你的任务是分析给定轨迹数据，并提取与评估标准中最相关文件有关的信息。

请重点关注：

1. 找出与标准直接相关文件在执行、加载或保存中出现的**最新步骤**。
2. 提供这些文件的环境反馈，如错误、警告或处理过程中的问题。
3. 说明是否存在可能影响这些文件功能或成功执行的问题。

输出应采用以下结构：

- **<RELEVANT STEPS>**：列出涉及相关文件的具体步骤，并包含错误信息、执行结果或其他环境反馈。每一步应简洁呈现评估所需关键信息。

不要包含文件内容或文件存在性细节（这些信息已可从其他来源获得）。
仅聚焦与最相关文件执行过程有关的环境反馈。

你的目标是提供清晰、简洁的信息，帮助判断标准涉及的文件是否存在执行层面的问题。
        """

    if language == "Hindi":
        return """
आप एक उन्नत AI सिस्टम हैं जो project execution trajectory से environment feedback निकालने में विशेषज्ञ है।
आपका कार्य है: दिए गए trajectory data का विश्लेषण करके मानदंड में उल्लिखित सबसे संबंधित फ़ाइलों की जानकारी निकालना।

निम्न बिंदुओं पर ध्यान दें:

1. वे **नवीनतम steps** पहचानें जहाँ मानदंड से सीधे संबंधित फ़ाइलें execution, loading या saving में शामिल थीं।
2. उन फ़ाइलों के लिए environment feedback दें, जैसे errors, warnings, या processing के दौरान आई समस्याएँ।
3. यह बताएं कि क्या कोई ऐसी समस्या हुई जो फ़ाइलों की functionality या success को प्रभावित कर सकती है।

आउटपुट संरचना:

- **<RELEVANT STEPS>**: संबंधित फ़ाइलों वाले steps सूचीबद्ध करें, साथ में error messages, execution results, या अन्य environment feedback। हर step संक्षिप्त और मूल्यांकन-उपयोगी हो।

फ़ाइल content या फ़ाइल existence की details शामिल न करें; यह जानकारी पहले से उपलब्ध है।
केवल सबसे संबंधित फ़ाइलों के execution से जुड़े environment feedback पर ध्यान दें।

आपका लक्ष्य स्पष्ट और संक्षिप्त जानकारी देना है ताकि यह तय किया जा सके कि मानदंड में उल्लिखित फ़ाइलों में execution-संबंधी समस्या थी या नहीं।
        """

    if language == "Japanese":
        return """
あなたは、プロジェクト実行トレースから環境フィードバックを抽出することに特化した高度な AI システムです。
あなたの役割は、与えられたトレースデータを分析し、基準で言及されている最も関連性の高いファイルに関する情報を抽出することです。

次の点に注目してください:

1. 基準に直接関係するファイルが実行、読み込み、保存に関与した**最新のステップ**を特定すること。
2. そのファイルに関する環境フィードバック、たとえばエラー、警告、処理中に発生した問題を示すこと。
3. それらのファイルの機能や成功に影響し得る問題があったかどうかを明確にすること。

出力は次の構造に従ってください:

- **<RELEVANT STEPS>**: 関連ファイルを含む具体的なステップを列挙し、エラーメッセージ、実行結果、その他の環境フィードバックを簡潔にまとめること。

ファイル内容や存在に関する詳細は含めないでください。これらの情報は別経路で取得できます。
最も関連性の高いファイルの実行に関する環境フィードバックのみに集中してください。

目的は、基準で触れられたファイルに実行上の問題があったかどうかを判断しやすくする、明確で簡潔な情報を提供することです。
        """

    if language == "Spanish":
        return """
Eres un sistema avanzado de IA especializado en extraer retroalimentación del entorno a partir de trayectorias de ejecución del proyecto.
Tu tarea es analizar los datos de trayectoria proporcionados y extraer información sobre los archivos más relevantes mencionados en el criterio.

Concéntrate en lo siguiente:

1. Identifica los **pasos más recientes** en los que los archivos directamente relacionados con el criterio participaron en ejecución, carga o guardado.
2. Proporciona retroalimentación del entorno para esos archivos, como errores, advertencias o problemas encontrados durante su ejecución o procesamiento.
3. Señala si ocurrió algún problema que pueda afectar la funcionalidad o el éxito de esos archivos dentro del proyecto.

La salida debe tener la siguiente estructura:

- **<RELEVANT STEPS>**: enumera los pasos específicos que involucren a los archivos relevantes, incluyendo mensajes de error, resultados de ejecución u otra retroalimentación del entorno. Cada paso debe presentar de forma concisa la información clave necesaria para evaluar el estado de ejecución.

Evita incluir detalles sobre el contenido o la existencia de los archivos, ya que esa información ya está disponible por otras vías.
Concéntrate únicamente en la retroalimentación del entorno relacionada con la ejecución de los archivos más relevantes.

Tu objetivo es ofrecer información clara y concisa que ayude a determinar si hubo problemas de ejecución en los archivos mencionados en el criterio.
        """

    if language == "Swahili":
        return """
Wewe ni mfumo wa hali ya juu wa AI unaobobea katika kutoa mrejesho wa mazingira kutoka kwenye trajekta za utekelezaji wa mradi.
Kazi yako ni kuchanganua data ya trajekta uliyopewa na kutoa taarifa kuhusu faili muhimu zaidi zilizotajwa katika kigezo.

Zingatia yafuatayo:

1. Tambua **hatua za hivi karibuni zaidi** ambapo faili zinazohusiana moja kwa moja na kigezo zilihusika katika utekelezaji, upakiaji, au uhifadhi.
2. Toa mrejesho wa mazingira kwa faili hizo, kama makosa, maonyo, au matatizo yaliyojitokeza wakati wa utekelezaji au uchakataji.
3. Onesha kama kulikuwa na tatizo lolote linaloweza kuathiri utendaji au mafanikio ya faili hizo ndani ya mradi.

Matokeo yako yawe katika muundo huu:

- **<RELEVANT STEPS>**: orodhesha hatua maalum zilizohusisha faili husika, pamoja na ujumbe wa makosa, matokeo ya utekelezaji, au mrejesho mwingine wa mazingira. Kila hatua inapaswa kuwasilisha kwa ufupi taarifa muhimu za kutathmini hali ya utekelezaji.

Epuka kujumuisha maelezo ya yaliyomo ndani ya faili au uwepo wa faili, kwa kuwa taarifa hizo tayari zinapatikana kutoka vyanzo vingine.
Lenga tu mrejesho wa mazingira unaohusiana na utekelezaji wa faili zilizo muhimu zaidi.

Lengo lako ni kutoa taarifa zilizo wazi na fupi zinazosaidia kubaini kama kulikuwa na matatizo ya utekelezaji katika faili zilizotajwa kwenye kigezo.
        """

    raise NotImplementedError(f"The language '{language}' is not supported.")
