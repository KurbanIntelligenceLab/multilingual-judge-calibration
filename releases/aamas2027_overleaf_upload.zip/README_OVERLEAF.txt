Upload as a new Overleaf project. Select main.tex and pdfLaTeX.
Keep the official aamas.cls and all figure files in their supplied locations.
Use Recompile from scratch. OpenReview submission 1655.
